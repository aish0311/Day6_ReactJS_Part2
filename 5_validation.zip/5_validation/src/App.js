import './App.css';
import ValidationDemo from './Components/ValidationDemo';

function App() {
  return (
    // <UseStateFun/>
    // <SetStateCLS/>
    <ValidationDemo/>
  );
}

export default App;
