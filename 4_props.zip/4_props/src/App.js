import './App.css';
//import PersonDefaultDemo from './Components/DefaultProp'
import ArrayAsProps from './Components/ArrayAsProps'
//import ParentSampleRenderProps from './Components/RenderPropDemo'
//import GrandParent from './Components/Live';


function App() {
  return(
    //Default Prop -Class Component with Props
    /*<div>
      <PersonDefaultDemo></PersonDefaultDemo>
      <PersonDefaultDemo name="Aishwarya Somaiya" gender="Female"></PersonDefaultDemo>
      <PersonDefaultDemo name="Ekta Vyas" gender="Female"></PersonDefaultDemo>
      <PersonDefaultDemo name="Shweta Brambhatt" gender="Female"></PersonDefaultDemo>
    </div> */

    //Array as Prop
    <ArrayAsProps></ArrayAsProps>

    
    //Render Props
    // <ParentSampleRenderProps/>
  );
 
}

export default App;

