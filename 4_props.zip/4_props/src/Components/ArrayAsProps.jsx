import React from 'react';
import  ReactDOM  from 'react-dom';

class ArrayAsProps extends React.Component{
    render(){
        return(
            <div>
                <h1>
                    {this.props.persons.map((per,index) => 
                    <>Person: {index+1} - {per} <br/></> )}
                </h1>
            </div>
        );
    }
}
// Passing an array as prop

ArrayAsProps.defaultProps = {person : ['Aishwarya Divan', 'Ekta Vyas' ,'Shweta Brambhatt']}

ReactDOM.render(<ArrayAsProps/>,document.getElementbyId("root"));

export default ArrayAsProps;
