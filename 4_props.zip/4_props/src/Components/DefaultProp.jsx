import React, {Component} from 'react';

class PersonDefaultDemo extends Component{
    render(){
        return(
            <>
            <p>Name: {this.props.name} </p>
            <p>Gender : {this.props.gender} </p>
            <hr/>
            </>
        )
    }
}

PersonDefaultDemo.defaultProps={
    name: "ABC",
    gender: "Female"
}

export default PersonDefaultDemo;